<?php
return array("#tableName"=>"payment","#primaryKeys"=>array("id"),"#manyToOne"=>array(),"#fieldNames"=>array("id"=>"id","payment_id"=>"payment_id"),"#fieldTypes"=>array("id"=>"int(11)","payment_id"=>"int(11)"),"#nullable"=>array(),"#notSerializable"=>array(),"#transformers"=>array(),"#accessors"=>array("id"=>"setId","payment_id"=>"setPayment_id"));
