<?php
return array("#tableName"=>"Cart","#primaryKeys"=>array(),"#manyToOne"=>array(),"#fieldNames"=>false,"#fieldTypes"=>array(),"#nullable"=>array(),"#notSerializable"=>array(),"#transformers"=>array(),"#accessors"=>array());
