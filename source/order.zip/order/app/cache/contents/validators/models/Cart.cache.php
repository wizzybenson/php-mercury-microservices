<?php
return array("id"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))),"cart_id"=>array(array("type"=>"notNull","constraints"=>array())));
