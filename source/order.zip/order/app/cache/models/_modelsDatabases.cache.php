<?php
return array("models\\Cart"=>"default","models\\Order"=>"default","models\\Phinxlog"=>"default","models\\Refund"=>"default");
