<?php

return array(
  '#namespace' => 'Ubiquity\\annotations',
  '#uses' => array (
),
  '#traitMethodOverrides' => array (
  'Ubiquity\\annotations\\OneToManyAnnotation' => 
  array (
  ),
),
);

