<?php
return array("id"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))),"order_id"=>array(array("type"=>"notNull","constraints"=>array())),"product_id"=>array(array("type"=>"notNull","constraints"=>array())),"quantity"=>array(array("type"=>"notNull","constraints"=>array())),"discount"=>array(array("type"=>"notNull","constraints"=>array())));
