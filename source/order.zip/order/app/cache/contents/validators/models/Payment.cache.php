<?php
return array("id"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))),"payment_id"=>array(array("type"=>"notNull","constraints"=>array())));
