<?php
return array("id"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))),"reason"=>array(array("type"=>"notNull","constraints"=>array())),"status"=>array(array("type"=>"length","constraints"=>array("max"=>255,"notNull"=>true))),"discussion"=>array(array("type"=>"length","constraints"=>array("max"=>255,"notNull"=>true))));
