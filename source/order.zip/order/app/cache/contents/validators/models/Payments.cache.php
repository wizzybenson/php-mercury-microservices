<?php
return array("id"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))));
