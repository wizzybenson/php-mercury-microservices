<?php
return array("id"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))),"created"=>array(array("type"=>"type","constraints"=>array("ref"=>"dateTime","notNull"=>true))));
