<?php

return array(
  '#namespace' => 'models',
  '#uses' => array (
  'Client' => 'GuzzleHttp\\Client',
),
  '#traitMethodOverrides' => array (
  'models\\Cart' => 
  array (
  ),
),
);

