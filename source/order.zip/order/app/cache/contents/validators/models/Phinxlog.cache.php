<?php
return array("version"=>array(array("type"=>"id","constraints"=>array("autoinc"=>true))),"migration_name"=>array(array("type"=>"length","constraints"=>array("max"=>100))),"breakpoint"=>array(array("type"=>"isBool","constraints"=>array("notNull"=>true))));
